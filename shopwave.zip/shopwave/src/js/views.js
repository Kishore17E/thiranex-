import { products, categories } from './data.js';
import { getCart } from './cart.js';
const $ = n => `$${n.toFixed(2)}`;
const card = p => `<a class="card" href="/product/${p.id}" data-link>
  <img src="${p.image}" alt="${p.name}" width="400" height="300" loading="lazy" decoding="async">
  <div><strong>${p.name}</strong><p class="mut">${p.category}</p><span class="price">${$(p.price)}</span></div></a>`;

export function catalog(_, q) {
  const s = (q.get('q') || '').toLowerCase(), cat = q.get('cat') || '';
  const list = products.filter(p => p.name.toLowerCase().includes(s) && (!cat || p.category === cat));
  return `<h1>Catalog</h1>
  <form class="tools" id="filters">
    <input name="q" placeholder="Search products" value="${q.get('q') || ''}">
    <select name="cat"><option value="">All</option>${categories.map(c => `<option ${c === cat ? 'selected' : ''}>${c}</option>`).join('')}</select>
    <button>Filter</button></form>
  <div class="grid">${list.map(card).join('') || '<p>No products found.</p>'}</div>`;
}
export function product([id]) {
  const p = products.find(x => x.id === +id);
  if (!p) return notFound();
  return `<div class="detail"><img src="${p.image}" alt="${p.name}" width="400" height="300">
  <div><h1>${p.name}</h1><p class="mut">${p.category}</p><p>${p.description}</p>
  <p class="price">${$(p.price)}</p><button data-add="${p.id}">Add to cart</button></div></div>`;
}
export function cart() {
  const c = getCart(), rows = Object.entries(c).map(([id, qty]) => ({ p: products.find(x => x.id === +id), qty })).filter(r => r.p);
  const total = rows.reduce((a, r) => a + r.p.price * r.qty, 0);
  return `<h1>Your Cart</h1>` + (rows.map(r => `<div class="row"><span>${r.p.name} × ${r.qty}</span>
    <span>${$(r.p.price * r.qty)} <button data-remove="${r.p.id}">Remove</button></span></div>`).join('') +
    `<h2>Total: ${$(total)}</h2>` || '') + (rows.length ? '' : '<p>Your cart is empty.</p>');
}
export const notFound = () => `<h1>404</h1><p>Page not found. <a href="/" data-link>Back to catalog</a></p>`;
