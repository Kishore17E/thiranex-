const routes = [];
export const route = (pattern, view) => routes.push({ re: new RegExp('^' + pattern + '$'), view });
export function navigate(url) { history.pushState({}, '', url); render(); }
export function render() {
  const { pathname, searchParams } = new URL(location.href);
  const app = document.getElementById('app');
  for (const { re, view } of routes) {
    const m = pathname.match(re);
    if (m) { app.innerHTML = view(m.slice(1), searchParams); break; }
  }
  window.scrollTo(0, 0);
}
export function initRouter(notFound) {
  route('.*', notFound); // last-resort fallback, registered after real routes in main.js
  document.addEventListener('click', e => {
    const a = e.target.closest('a[data-link]');
    if (a) { e.preventDefault(); navigate(a.getAttribute('href')); }
  });
  addEventListener('popstate', render);
  render();
}
