import { route, initRouter, navigate, render } from './router.js';
import { catalog, product, cart, notFound } from './views.js';
import { add, remove, refresh } from './cart.js';

route('/', catalog);
route('/product/(\\d+)', product);
route('/cart', cart);
refresh();
initRouter(notFound);

document.addEventListener('submit', e => {
  if (e.target.id !== 'filters') return;
  e.preventDefault();
  const p = new URLSearchParams(new FormData(e.target));
  [...p].forEach(([k, v]) => !v && p.delete(k));
  navigate('/' + (p.toString() ? '?' + p : ''));
});
document.addEventListener('click', e => {
  if (e.target.dataset.add) { add(+e.target.dataset.add); e.target.textContent = 'Added ✓'; }
  if (e.target.dataset.remove) { remove(+e.target.dataset.remove); render(); }
});
