const items = [
  ['Wireless Headphones','Audio',89,'#5b4bff'],['Mechanical Keyboard','Computers',129,'#ff6b6b'],
  ['Smart Watch','Wearables',199,'#00b894'],['Bluetooth Speaker','Audio',59,'#fdcb6e'],
  ['USB-C Hub','Computers',45,'#0984e3'],['Fitness Band','Wearables',49,'#e17055'],
  ['Webcam 1080p','Computers',69,'#6c5ce7'],['Earbuds Pro','Audio',119,'#00cec9']
];
// Lightweight inline SVG placeholders (zero network requests). Swap for real .webp files in /public/img.
const img = (c, t) => 'data:image/svg+xml,' + encodeURIComponent(
  `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300"><rect width="400" height="300" fill="${c}"/><text x="200" y="160" font-size="26" fill="#fff" text-anchor="middle" font-family="sans-serif">${t}</text></svg>`);
export const products = items.map(([name, category, price, c], i) => ({
  id: i + 1, name, category, price, image: img(c, name),
  description: `${name} - premium quality, fast shipping and a 1-year warranty.`
}));
export const categories = [...new Set(products.map(p => p.category))];
