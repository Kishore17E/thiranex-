const KEY = 'shopwave-cart';
export const getCart = () => { try { return JSON.parse(localStorage.getItem(KEY)) || {}; } catch { return {}; } };
const save = c => { localStorage.setItem(KEY, JSON.stringify(c)); document.getElementById('count').textContent = count(); };
export const count = () => Object.values(getCart()).reduce((a, b) => a + b, 0);
export const add = id => { const c = getCart(); c[id] = (c[id] || 0) + 1; save(c); };
export const remove = id => { const c = getCart(); delete c[id]; save(c); };
export const refresh = () => save(getCart());
