# ShopWave - E-commerce Capstone

Vanilla JS (ES modules) + Vite. Client-side routing via the History API.

## Structure
src/js/{main,router,views,cart,data}.js - one responsibility per module
src/css/styles.css - responsive, dark-mode aware

## Run
npm install && npm run dev
npm run build   # minified output in dist/

## Deploy
Vercel: push to GitHub -> vercel.com/new -> import repo (vercel.json handles SPA rewrites).
Netlify: import repo (netlify.toml handles build + redirects).
Render: Static Site, build `npm run build`, publish `dist`, add rewrite /* -> /index.html.

## Performance
Lazy-loaded images with width/height (no layout shift), inline SVG placeholders, Vite minification + hashing.
Replace placeholders with .webp images in src/public/img for production.
